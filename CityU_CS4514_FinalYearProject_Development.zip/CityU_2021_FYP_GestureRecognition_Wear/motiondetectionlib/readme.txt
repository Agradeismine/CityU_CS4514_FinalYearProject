To upload artifact to bintray:
export bintray_user=...
export bintray_key=
./gradlew install
./gradlew bintrayUpload